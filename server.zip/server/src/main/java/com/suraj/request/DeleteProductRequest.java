package com.suraj.request;

public class DeleteProductRequest {
	
//	private Long 

}
