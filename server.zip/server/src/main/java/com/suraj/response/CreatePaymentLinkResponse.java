package com.suraj.response;

public class CreatePaymentLinkResponse {
	
	

}
