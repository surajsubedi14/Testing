package com.suraj.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
